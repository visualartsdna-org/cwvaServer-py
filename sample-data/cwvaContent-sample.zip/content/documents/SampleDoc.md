## Sample Doc

I keep extensive remarks and commentary about Confrontation here.